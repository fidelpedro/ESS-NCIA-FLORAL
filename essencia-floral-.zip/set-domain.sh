#!/bin/sh
# Uso: sh set-domain.sh https://www.seudominio.com
[ -z "$1" ] && echo "Indique o dominio final" && exit 1
sed -i.bak "s#https://DOMINIO#$1#g" *.html sitemap.xml robots.txt && rm -f *.bak && echo "Dominio atualizado para $1"

# Essência Floral — site institucional

Site estático (HTML, CSS e JavaScript puro, sem dependências de build), pronto para a Netlify.

## Publicar na Netlify
Arraste a pasta (ou o ZIP extraído) para app.netlify.com/drop, ou ligue o repositório. Não é preciso comando de build.

## Domínio final
Enquanto o domínio não estiver definido, canonical, Open Graph, sitemap, robots e schema usam `https://DOMINIO`.
Depois de saber o endereço, execute `sh set-domain.sh https://seudominio.com` (ou substitua `https://DOMINIO` nos ficheiros .html, sitemap.xml e robots.txt) e submeta o sitemap no Google Search Console.

## Páginas
index, sobre, colecao, ocasioes, clientes-atendidos, galeria, tatiana e contactos (cada uma com title, description e canonical próprios).
A fotografia da Tatiana está em `assets/images/founder/`.

## Fotografias
As fotos dos clientes têm 206x206 px, pelo que ficam nítidas apenas em tamanhos pequenos. Para melhor resultado em ecrãs grandes, substitua-as por originais (mín. 1200 px) mantendo os nomes em `assets/images/clients/` (versões `.webp`, `@2x.webp` e `.jpg`).

## Estrutura
os 8 ficheiros .html, css/style.css, js/script.js, assets/ (images, videos, fonts, icons), favicon/, robots.txt, sitemap.xml, netlify.toml.
As fontes (Cormorant Garamond e Manrope) carregam do Google Fonts, com alternativas do sistema caso falhem.

## Vídeo de fundo
Telemóveis e tablets na vertical usam `assets/videos/hero-mobile.mp4` (vertical 720x1280); PC e tablets na horizontal usam `hero.mp4`. O aparelho troca de vídeo ao rodar. Se o autoplay for bloqueado (por exemplo poupança de bateria no iPhone), fica a imagem de capa `hero-mobile-poster.webp` / `hero-poster.webp`.

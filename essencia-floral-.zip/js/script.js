(function () {
  'use strict';
  var WA = '244928554408';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var body = document.body;

  /* WhatsApp dinamico */
  function wa(msg) { return 'https://wa.me/' + WA + '?text=' + encodeURIComponent(msg); }
  $$('[data-wa]').forEach(function (a) {
    a.href = wa(a.getAttribute('data-wa'));
    a.target = '_blank'; a.rel = 'noopener noreferrer';
  });
  $$('[data-product]').forEach(function (a) {
    var n = a.getAttribute('data-product');
    a.href = wa('Olá, Essência Floral! Gostaria de encomendar o produto ' + n + '.');
    a.target = '_blank'; a.rel = 'noopener noreferrer';
  });

  /* text reveal: divide em palavras */
  $$('.tr').forEach(function (el) {
    var i = 0;
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 3) {
          var frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach(function (t) {
            if (!t) return;
            if (/^\s+$/.test(t)) { frag.appendChild(document.createTextNode(' ')); return; }
            var w = document.createElement('span'); w.className = 'w';
            var s = document.createElement('i'); s.style.setProperty('--i', i++); s.textContent = t;
            w.appendChild(s); frag.appendChild(w);
          });
          node.replaceChild(frag, n);
        } else if (n.nodeType === 1) walk(n);
      });
    })(el);
  });

  /* loader */
  var drawer_open = function () { var d = document.getElementById('drawer'); return d && d.classList.contains('open'); };
  var loader = $('#loader');
  var opened = false;
  function openSite() {
    if (opened) return; opened = true;
    if (loader) loader.classList.add('done');
    setTimeout(function () { body.classList.add('ready'); body.classList.remove('lock'); }, 350);
    if (loader) setTimeout(function () { loader.style.display = 'none'; }, 1400);
  }
  body.classList.add('lock');
  setTimeout(function () { var l = document.getElementById('lb'); if (!drawer_open() && !(l && l.classList.contains('open'))) { body.classList.remove('lock'); } }, 6000);
  var minWait = new Promise(function (r) { setTimeout(r, (reduce || !loader) ? 80 : 1900); });
  var loaded = new Promise(function (r) { if (document.readyState === 'complete') r(); else window.addEventListener('load', r); });
  Promise.all([minWait, Promise.race([loaded, new Promise(function (r) { setTimeout(r, 3500); })])]).then(openSite);

  /* video de fundo: mobile/tablet vertical usam o video vertical, PC e tablet horizontal o video largo */
  var mqMobile = window.matchMedia('(max-width: 820px), (orientation: portrait) and (max-width: 1100px)');
  var saver = navigator.connection && (navigator.connection.saveData || /2g/.test(navigator.connection.effectiveType || ''));
  function bgVideo(v, lazy) {
    if (!v) return;
    if (reduce || saver) { v.remove(); return; }
    v.muted = true; v.defaultMuted = true; v.setAttribute('muted', ''); v.setAttribute('playsinline', ''); v.setAttribute('webkit-playsinline', '');
    var cur = '';
    function pick() { return mqMobile.matches ? v.dataset.mobile : v.dataset.desktop; }
    function start() {
      var src = pick();
      if (src !== cur) { cur = src; v.classList.remove('vplay'); v.src = src; v.load(); }
      var p = v.play(); if (p && p.catch) p.catch(function () {});
    }
    v.addEventListener('playing', function () { v.classList.add('vplay'); });
    v.addEventListener('error', function () { v.classList.remove('vplay'); });
    var go = function () { start(); };
    if (lazy && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (e, o) { if (e[0].isIntersecting) { go(); o.disconnect(); } }, { rootMargin: '300px' }).observe(v);
    } else go();
    /* troca de video ao rodar o aparelho ou redimensionar */
    var swap = function () { if (cur && pick() !== cur) start(); };
    if (mqMobile.addEventListener) mqMobile.addEventListener('change', swap); else if (mqMobile.addListener) mqMobile.addListener(swap);
    /* iOS em modo de poupanca bloqueia autoplay: tenta de novo no primeiro toque */
    ['touchstart', 'click', 'scroll'].forEach(function (ev) {
      window.addEventListener(ev, function once() { if (cur && v.paused) { var q = v.play(); if (q && q.catch) q.catch(function () {}); } window.removeEventListener(ev, once); }, { passive: true });
    });
    /* poupar bateria: pausa quando fora do ecra ou separador oculto */
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (e) {
        if (!cur) return;
        if (e[0].isIntersecting) { var q = v.play(); if (q && q.catch) q.catch(function () {}); } else v.pause();
      }, { threshold: 0 }).observe(v);
    }
  }
  bgVideo($('#heroVideo'), false);
  bgVideo($('#finalVideo'), true);

  /* nav */
  var nav = $('#nav'), waBtn = $('.wa');
  function onScroll() {
    var y = window.scrollY;
    nav.classList.toggle('solid', y > 40);
    waBtn.classList.toggle('show', y > window.innerHeight * .6);
  }
  var drawer = $('#drawer'), burger = $('#burger');
  function toggleMenu(open) {
    burger.setAttribute('aria-expanded', open);
    burger.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
    drawer.classList.toggle('open', open);
    drawer.setAttribute('aria-hidden', !open);
    body.classList.toggle('lock', open);
  }
  burger.addEventListener('click', function () { toggleMenu(burger.getAttribute('aria-expanded') !== 'true'); });
  $$('a', drawer).forEach(function (a) { a.addEventListener('click', function () { toggleMenu(false); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && drawer.classList.contains('open')) toggleMenu(false); });

  /* link ativo */
  var links = $$('.menu a');
  if ('IntersectionObserver' in window) {
    var so = links.length && new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (en.isIntersecting) links.forEach(function (l) { l.classList.toggle('active', l.getAttribute('href') === '#' + en.target.id); });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    links.forEach(function (l) { var t = $(l.getAttribute('href')); if (t) so.observe(t); });
  }

  /* reveal */
  var rv = $$('[data-r],.tr');
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: .14, rootMargin: '0px 0px -6% 0px' });
    rv.forEach(function (el) { io.observe(el); });
  } else rv.forEach(function (el) { el.classList.add('in'); });

  /* parallax por scroll */
  var px = $$('[data-speed]');
  var ticking = false;
  function par() {
    var vh = window.innerHeight;
    px.forEach(function (el) {
      var r = el.parentElement.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      var s = parseFloat(el.dataset.speed) * (window.innerWidth < 720 ? .4 : 1);
      var d = (r.top + r.height / 2 - vh / 2) * s;
      el.style.transform = 'translate3d(0,' + d.toFixed(1) + 'px,0)';
    });
    ticking = false;
  }
  window.addEventListener('scroll', function () {
    onScroll();
    if (!reduce && !ticking) { ticking = true; requestAnimationFrame(par); }
  }, { passive: true });
  window.addEventListener('resize', par);
  onScroll(); if (!reduce) par();

  /* movimento por cursor + tilt 3D */
  if (fine && !reduce) {
    var hero = $('.hero'), fl = $$('.float');
    if (hero) hero.addEventListener('mousemove', function (e) {
      var x = e.clientX / window.innerWidth - .5, y = e.clientY / window.innerHeight - .5;
      fl.forEach(function (f) {
        var d = parseFloat(f.dataset.depth || 30);
        f.style.transform = 'translate3d(' + (x * d).toFixed(1) + 'px,' + (y * d).toFixed(1) + 'px,0) rotate(' + (x * d * .3).toFixed(1) + 'deg)';
      });
    });
    $$('[data-tilt]').forEach(function (el) {
      var inner = $('.card-in,.tile-in', el) || el;
      el.addEventListener('mousemove', function (e) {
        var r = el.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        inner.style.transform = 'rotateY(' + (x * 7).toFixed(2) + 'deg) rotateX(' + (-y * 7).toFixed(2) + 'deg)';
      });
      el.addEventListener('mouseleave', function () { inner.style.transform = ''; });
    });
  }

  /* filtros: so aparecem categorias com conteudo */
  var tiles = $$('.mason .tile');
  var cats = {};
  tiles.forEach(function (t) { var c = t.dataset.cat; cats[c] = (cats[c] || 0) + 1; });
  var order = ['buques', 'noivas', 'boxes', 'arranjos', 'formaturas', 'entregas', 'clientes'];
  var names = { buques: 'Buquês', noivas: 'Noivas', boxes: 'Boxes', arranjos: 'Arranjos', formaturas: 'Formaturas', entregas: 'Entregas', clientes: 'Clientes' };
  var fbox = $('#filters');
  var present = order.filter(function (c) { return cats[c]; });
  if (fbox && present.length > 1 && tiles.length >= 6) {
    ['todos'].concat(present).forEach(function (c, i) {
      var b = document.createElement('button');
      b.type = 'button'; b.textContent = c === 'todos' ? 'Todos' : names[c];
      b.dataset.f = c; if (!i) b.className = 'on'; b.setAttribute('aria-pressed', !i);
      fbox.appendChild(b);
    });
    fbox.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      $$('button', fbox).forEach(function (x) { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
      tiles.forEach(function (t) { t.classList.toggle('hide', b.dataset.f !== 'todos' && t.dataset.cat !== b.dataset.f); });
    });
  } else if (fbox) fbox.remove();

  /* lightbox */
  var lb = $('#lb'), lbImg = $('#lbImg'), lbCount = $('#lbCount'), lbCap = $('#lbCap');
  var lastFocus, cur = 0, list = [];
  function visibleList() { return $$('[data-lb]').filter(function (el) { return !el.closest('.hide'); }); }
  function show(i, first) {
    cur = (i + list.length) % list.length;
    var el = list[cur], src = el.dataset.full, alt = el.dataset.alt;
    var apply = function () { lbImg.src = src; lbImg.alt = alt; lbImg.classList.remove('swap'); };
    lbCount.textContent = String(cur + 1).padStart(2, '0') + ' / ' + String(list.length).padStart(2, '0');
    lbCap.textContent = el.dataset.cap || '';
    if (first || reduce) apply(); else { lbImg.classList.add('swap'); setTimeout(apply, 220); }
  }
  function openLb(el) {
    list = visibleList(); lastFocus = document.activeElement;
    lb.classList.add('open'); lb.setAttribute('aria-hidden', 'false'); body.classList.add('lock');
    show(list.indexOf(el), true); $('.x', lb).focus();
  }
  function closeLb() { lb.classList.remove('open'); lb.setAttribute('aria-hidden', 'true'); body.classList.remove('lock'); if (lastFocus) lastFocus.focus(); }
  $$('[data-lb]').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); openLb(el); });
  });
  $('.x', lb).addEventListener('click', closeLb);
  $('.pv', lb).addEventListener('click', function () { show(cur - 1); });
  $('.nx', lb).addEventListener('click', function () { show(cur + 1); });
  lb.addEventListener('click', function (e) { if (e.target.classList.contains('lb-stage') || e.target === lb) closeLb(); });
  document.addEventListener('keydown', function (e) {
    if (!lb.classList.contains('open')) return;
    if (e.key === 'Escape') closeLb();
    else if (e.key === 'ArrowRight') show(cur + 1);
    else if (e.key === 'ArrowLeft') show(cur - 1);
    else if (e.key === 'Tab') { var f = $$('button', lb), a = document.activeElement; if (e.shiftKey && a === f[0]) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && a === f[f.length - 1]) { e.preventDefault(); f[0].focus(); } }
  });
  var sx = 0, sy = 0;
  lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
  lb.addEventListener('touchend', function (e) {
    var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) show(cur + (dx < 0 ? 1 : -1));
    else if (dy > 90 && Math.abs(dy) > Math.abs(dx)) closeLb();
  }, { passive: true });

  /* ano */
  var y = $('#year'); if (y) y.textContent = new Date().getFullYear();
})();
